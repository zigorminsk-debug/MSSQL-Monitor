# How to perform bulk imports

To use the bulk imports feature in go-mssqldb, you need to import the sql and go-mssqldb packages.

```
import (
    "database/sql"
    "github.com/microsoft/go-mssqldb"
)
```

The `mssql.CopyIn` function creates a string which can be prepared by passing it to `Prepare`. The string returned contains information such as the name of the table and columns to bulk import data into, and bulk options.

```
bulkImportStr := mssql.CopyIn("tablename", mssql.BulkOptions{}, "column1", "column2", "column3")
stmt, err := db.Prepare(bulkImportStr)
```

The table name is treated as an object name and is quoted before it is sent to the server, so a name that is not a regular identifier does not need to be delimited by the caller. It may be qualified, and individual parts may be delimited.

```
bulkImportStr := mssql.CopyIn("[my schema].[my table]", mssql.BulkOptions{}, "column1")
```

Because the destination is always an object name, a value that relied on being spliced into the statement as raw text no longer resolves. Pass the table name and the matching option instead of appending the clause to the name, for example `mssql.CopyIn("tablename", mssql.BulkOptions{Tablock: true}, "column1")` rather than `mssql.CopyIn("tablename WITH (TABLOCK)", ...)`. A name that cannot identify an object, because it is empty or has more than the four parts SQL Server allows, is reported before any statement is sent.

Bulk options can be specified using the `mssql.BulkOptions` type. The following is how the `BulkOptions` type is defined:

```
type BulkOptions struct {
    CheckConstraints  bool
    FireTriggers      bool
    KeepNulls         bool
    KilobytesPerBatch int
    RowsPerBatch      int
    Order             []string
    Tablock           bool
}
```

Each `Order` entry names one or more destination columns, separated by commas, each optionally followed by `ASC` or `DESC`. Column names are quoted the same way the table name is, so a column name that ends in `asc` or `desc`, or that contains a comma, has to be delimited to be told apart from a sort direction or a separator.

```
mssql.BulkOptions{Order: []string{"column1 DESC", "[my column]"}}
mssql.BulkOptions{Order: []string{"column1 DESC, [my column]"}}
```

The statement can be executed many times to copy data into the table specified.

```
for i := 0; i < 10; i++ {
	_, err = stmt.Exec(col1Data[i], col2Data[i], col3Data[i])
}
```

After all the data is processed, call `Exec` once with no arguments to flush all the buffered data.

```
_, err = stmt.Exec()
```

## Example
[Bulk import example](../bulkimport_example_test.go)